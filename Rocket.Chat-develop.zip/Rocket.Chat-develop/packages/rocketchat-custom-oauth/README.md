# Custom OAuth

An implementation of the OAuth2 flow. It works with your own private OAuth2 server instance.

This software is supplied courtesy of the [Rocket.Chat](https://rocket.chat/) open source communications platform.

See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.
