RocketChat.emoji = {
	packages: {
		base: {
			emojiCategories: { recent: TAPi18n.__('Frequently_Used') },
			emojisByCategory: {
				recent: []
			},
			toneList: {},
			render(html) {
				return html;
			}
		}
	},
	list: {}
};
