RocketChat.theme.addPackageAsset(function() {
	return Assets.getText('emojiPicker.less');
});
