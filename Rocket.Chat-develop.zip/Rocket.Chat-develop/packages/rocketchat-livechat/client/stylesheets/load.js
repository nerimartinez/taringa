RocketChat.theme.addPackageAsset(() => {
	return Assets.getText('client/stylesheets/livechat.less');
});
