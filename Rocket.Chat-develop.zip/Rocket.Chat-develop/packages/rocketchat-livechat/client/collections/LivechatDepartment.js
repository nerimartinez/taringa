this.LivechatDepartment = new Mongo.Collection('rocketchat_livechat_department');
