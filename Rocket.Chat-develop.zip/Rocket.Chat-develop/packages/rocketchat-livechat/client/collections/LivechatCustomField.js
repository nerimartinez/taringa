this.LivechatCustomField = new Mongo.Collection('rocketchat_livechat_custom_field');
