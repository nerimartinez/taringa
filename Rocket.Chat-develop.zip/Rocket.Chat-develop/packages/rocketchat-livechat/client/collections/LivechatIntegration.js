this.LivechatIntegration = new Mongo.Collection('livechatIntegration');
