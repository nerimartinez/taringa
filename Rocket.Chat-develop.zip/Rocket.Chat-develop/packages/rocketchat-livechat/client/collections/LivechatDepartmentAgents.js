this.LivechatDepartmentAgents = new Mongo.Collection('rocketchat_livechat_department_agents');
