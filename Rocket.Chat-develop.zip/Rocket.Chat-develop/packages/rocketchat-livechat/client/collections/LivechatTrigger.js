this.LivechatTrigger = new Mongo.Collection('rocketchat_livechat_trigger');
