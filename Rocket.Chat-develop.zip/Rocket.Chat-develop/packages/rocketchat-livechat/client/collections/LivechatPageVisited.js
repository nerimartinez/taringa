this.LivechatPageVisited = new Mongo.Collection('rocketchat_livechat_page_visited');
