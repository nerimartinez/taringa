this.AgentUsers = new Mongo.Collection('agentUsers');
