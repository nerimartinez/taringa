this.LivechatInquiry = new Mongo.Collection('rocketchat_livechat_inquiry');
