this.LivechatQueueUser = new Mongo.Collection('livechatQueueUser');
