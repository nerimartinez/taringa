/* globals CustomFields */

Meteor.startup(function() {
	CustomFields.init();
});
