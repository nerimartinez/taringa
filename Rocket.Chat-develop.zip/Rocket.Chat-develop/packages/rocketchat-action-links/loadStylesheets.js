RocketChat.theme.addPackageAsset(function() {
	return Assets.getText('client/stylesheets/actionLinks.less');
});
