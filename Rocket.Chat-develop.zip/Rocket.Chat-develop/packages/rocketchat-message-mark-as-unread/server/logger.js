/* globals logger:true */
/* exported logger */

logger = new Logger('MessageMarkAsUnread', {
	sections: {
		connection: 'Connection',
		events: 'Events'
	}
});
