# Publish commands

```
cd Rocket.Chat
vagrant-spk up && vagrant-spk dev
^C
vagrant-spk pack ../rocketchat.spk && vagrant-spk publish ../rocketchat.spk && vagrant-spk halt
```
